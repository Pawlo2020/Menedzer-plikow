package com.example.s1mplefilemanager.handlers;

import com.example.s1mplefilemanager.handlers.interfaces.IArchiver;

import java.util.List;
import java.util.zip.ZipInputStream;

public class ZipArchiver implements IArchiver {

    private ZipInputStream ZipHandler;

    @Override
    public void unpack(String source, String destination) {

    }

    @Override
    public void pack(List<FileHandler> files, String destination) {

    }
}
