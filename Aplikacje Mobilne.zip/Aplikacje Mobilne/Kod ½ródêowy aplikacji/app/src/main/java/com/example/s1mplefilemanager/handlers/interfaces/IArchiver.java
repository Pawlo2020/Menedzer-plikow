package com.example.s1mplefilemanager.handlers.interfaces;
import com.example.s1mplefilemanager.handlers.FileHandler;

import java.util.List;

public interface IArchiver {
    void unpack(String source, String destination);
    void pack(List<FileHandler> files, String destination);

}
