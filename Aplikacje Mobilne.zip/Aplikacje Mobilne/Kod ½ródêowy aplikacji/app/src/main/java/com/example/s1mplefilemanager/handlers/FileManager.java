package com.example.s1mplefilemanager.handlers;

import com.example.s1mplefilemanager.handlers.interfaces.IFileOperations;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FileManager implements IFileOperations {

    String currentPath;


    @Override
    public void create(FileHandler file, String path) {

    }

    @Override
    public void copy(FileHandler file, String destination_path) {

    }

    @Override
    public void delete(FileHandler file) {

    }

    @Override
    public List<FileHandler> sort(List<FileHandler> listToSort) {
        List<FileHandler> files = loadFile(currentPath);
        files.sort((FileHandler f1, FileHandler f2) -> f1.getInformations().getName().compareTo(f2.getInformations().getName()));
        return files;
    }

    @Override
    public AdditionalInformations getFileInformations(int index) {
        List<FileHandler> files = loadFile(currentPath);

        AdditionalInformations info = files.get(index).getInformations();
        return info;
    }

    @Override
    public FileHandler getFile(int index) {
        List<FileHandler> files = loadFile(currentPath);

        return files.get(index);
    }

    @Override
    public List<FileHandler> loadFile(String path) {
        currentPath = path;
        List<FileHandler> files = new ArrayList<FileHandler>();
        File directory = new File(path);
        File[] filesTemp = directory.listFiles();

        for(File file : filesTemp){
            files.add(new FileHandler(file));
        }
        return files;
    }
}
