package com.example.s1mplefilemanager.ui.externalStorage;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ExternalStorageViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public ExternalStorageViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is external fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}