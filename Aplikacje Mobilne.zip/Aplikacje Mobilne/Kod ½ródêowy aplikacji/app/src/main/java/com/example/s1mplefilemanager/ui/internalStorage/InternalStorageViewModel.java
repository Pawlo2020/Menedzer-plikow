package com.example.s1mplefilemanager.ui.internalStorage;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.io.File;

public class InternalStorageViewModel extends ViewModel {

    private MutableLiveData<String> mText;
    private String path;
    private File[] files;
    private File file;

    public File[] getFiles() {
        File directory = new File(this.path);
        this.files = directory.listFiles();
        return files;
    }

    public InternalStorageViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is internal fragment");




    }

    public LiveData<String> getText() {
        return mText;
    }
}