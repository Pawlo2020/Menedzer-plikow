package com.example.s1mplefilemanager.handlers;

import java.io.File;

public class FileHandler {

    private String path;
    private String extension;

    private File content;

    public FileHandler(File file){
        content = file;
        informations = new AdditionalInformations();
        informations.setName(file.getName());
        informations.setCapacity(file.getTotalSpace());

    }


    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public AdditionalInformations getInformations() {
        return informations;
    }

    public void setInformations(AdditionalInformations informations) {
        this.informations = informations;
    }

    private AdditionalInformations informations;



}
