package com.example.s1mplefilemanager.handlers;

import com.example.s1mplefilemanager.handlers.interfaces.IArchiver;

import java.util.List;

public class RarArchiver implements IArchiver {



    @Override
    public void unpack(String source, String destination) {

    }

    @Override
    public void pack(List<FileHandler> files, String destination) {

    }
}
