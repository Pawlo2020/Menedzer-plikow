package com.example.s1mplefilemanager.ui.images;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ImagesViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public ImagesViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is image fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}