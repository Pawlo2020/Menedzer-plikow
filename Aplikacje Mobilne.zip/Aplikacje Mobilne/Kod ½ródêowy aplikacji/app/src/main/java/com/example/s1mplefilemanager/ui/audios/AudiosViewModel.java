package com.example.s1mplefilemanager.ui.audios;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AudiosViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public AudiosViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is audios fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}