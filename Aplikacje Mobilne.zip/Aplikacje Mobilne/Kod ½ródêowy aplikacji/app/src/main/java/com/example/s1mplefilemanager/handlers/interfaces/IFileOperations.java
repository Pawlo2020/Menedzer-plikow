package com.example.s1mplefilemanager.handlers.interfaces;

import com.example.s1mplefilemanager.handlers.AdditionalInformations;
import com.example.s1mplefilemanager.handlers.FileHandler;

import java.util.List;

public interface IFileOperations {
    void create(FileHandler file, String path);
    void copy(FileHandler file, String destination_path);
    void delete(FileHandler file);
    List<FileHandler> sort(List<FileHandler> listToSort);
    AdditionalInformations getFileInformations(int index);
    FileHandler getFile(int index);
    List<FileHandler> loadFile(String path);
}
