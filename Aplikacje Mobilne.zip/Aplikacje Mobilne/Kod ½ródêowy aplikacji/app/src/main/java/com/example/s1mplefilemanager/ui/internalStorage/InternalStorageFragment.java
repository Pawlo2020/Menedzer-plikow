package com.example.s1mplefilemanager.ui.internalStorage;

import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.s1mplefilemanager.R;
import com.example.s1mplefilemanager.handlers.FileHandler;
import com.example.s1mplefilemanager.handlers.FileManager;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class InternalStorageFragment extends Fragment {

    private InternalStorageViewModel internalStorageViewModel;

    private RecyclerView fileList;
    FileManager manager;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        internalStorageViewModel =
                ViewModelProviders.of(this).get(InternalStorageViewModel.class);

        manager = new FileManager();


        View root = inflater.inflate(R.layout.fragment_internalstorage, container, false);


        List<FileHandler> files = manager.loadFile(Environment.getRootDirectory().getPath());

        FileListAdapter adapter = new FileListAdapter(files, this);

        fileList = (RecyclerView)root.findViewById(R.id.internalFileList);


        fileList.setAdapter(adapter);

//        final TextView textView = root.findViewById(R.id.text_internal);
        internalStorageViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
//                textView.setText(s);
            }
        });
        return root;
    }
}